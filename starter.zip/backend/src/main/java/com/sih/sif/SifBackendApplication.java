package com.sih.sif;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SifBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SifBackendApplication.class, args);
	}

}
